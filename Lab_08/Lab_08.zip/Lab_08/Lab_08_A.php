<html>
	<body>
		<h1>Task 01 (Factorial)</h1>
		<form method="post">  
			Enter any Number: <input type="number" name="num"/><br><br>  
			<input type="submit" name="show" value="Generate"/>
		</form>     
	</body>
</html>
<?php
	function getFactorial($num)
	{
		if($num==0)
		{
			return 1;
		}
		else if($num<0)
		{
			return "Number should be positive";
		}
		else if($num>0)
		{
			return ($num * getFactorial($num-1));
		}
	}
	if (isset($_POST['num'])) 
	{
 		echo "Factorial = ".getFactorial($_POST["num"])."<br>";
 	}
?>

<!-- ///////////////////////////////////////////////////////// -->
<html>
	<body>
		<h1>Task 02 (Power Generation) </h1>
		<form method="post">  
			Enter any Number as Base: <input type="number" name="num1"/><br><br> 
			Enter any Number as Exponent: <input type="number" name="num2"/><br><br>  
			<input type="submit" name="power" value="Generate"/>
		</form>     
	</body>
</html>
<?php
	function getPower($num1, $num2)
	{
		$power = 0;
		for($i=1; $i<$num2; $i++)
		{
			$power = $power+($num1 * $num1);
		}
		return $power;	
	}
	if (isset($_POST['num1']) && isset($_POST['num2'])) 
	{
    	echo "Power = ".getPower($_POST['num1'], $_POST['num2']);	
	}
?>
<!------------------------------------------------------------>
<?php
echo "<h1>Task 3 (Function Overloading) </h1> "; 


function arth(...$a)
{
    $addition = 0;
    $subtration = 0;
    $multiply = 0;
    $divsion = 0;
    $try1 = true;
    $try1Mul = true;
    $try1Div = true;

    foreach($a as $v)
    {
        $addition += $v; // Addition
        if($try1 == true)
        { //Subtraction
            $subtration = $v;
            $try1 = false;
        }
        else
            $subtration  = $subtration - $v;
        
        if($try1Mul == true)
        { // Multiply
            $mul = $v;
            $try1Mul = false;
        }
        else
            $multiply = $multiply * $v;
        
        if($try1Div == true)
        { // Division
            $divsion = $v;
            $try1Div = false;
        }
        else
            $division = $divsion / $v;
    }
    return "Addition: ".$addition.
    		"<br> Subtraction: ".$subtration.
    		"<br> Multiply: ".$multiply.
    		"<br> Division: ".$division;
}

echo "<h3>Function with 2 Arguments</h3>";
echo arth(64,62);

echo "<h3>Function with 3 Arguments</h3>";
echo arth(64,62,100);

?>
<!--///////////////////////////////////////////////////////////// -->
<?php
	echo "<h1>Task 04 (Overloading Using Magic Function) </h1>";
	class DemoMagic
	{
		function __Call($name, $args){
        if($name == "Bhatti")
        {
        	$size = sizeof($args);
        	if($size == 0)
        	{
        		echo "No any Arguments"."<br>";
        	}
        	elseif($size == 1)
        	{
        		 echo "Single Argument: ".$args[0]."<br>";
        	}
        	elseif($size==2)
        	{
        		echo "Two Arguments: ".$args[0]." ".$args[1]."<br>";
        	}
        	elseif($size==3)
        	{
        		echo "Two args: ".$args[0]." ".$args[1]." ".$args[2]."<br>";
        	}
        	elseif($args>3)
        	{
        		foreach ($args as $a) 
        		{
        			echo $a. " ";
        		}
        	}
		}
	}
}
$ob = new DemoMagic();
$ob-> Bhatti();
$ob-> Bhatti("Bhatti");
$ob-> Bhatti("Bhatti", "Azhar");
$ob-> Bhatti("Bhatti", "Azhar", "Hussain");
$ob-> Bhatti("Bhatti", "Azhar", "Hussain", "Baloch");

	
?>
<!-- /////////////////////////////////////////////////////////// -->
<html>
	<body>
		<h1>Task 05 (Armstrong Number)</h1>
		<form method="post">  
			Enter any Number <input type="number" name="num"/><br><br> 
			<input type="submit" name="check" value="Check"/>
		</form>     
	</body>
</html>

<?php
	function checkArmstrong($num)
	{
		$temp = $num;
		$check = $num;
		$c = 0;
		while($temp>0)  
   		{  
    		$a=$temp%10;  
		    $temp=$temp/10;  
		    $c=$c+($a*$a*$a);  
	    }  
		if($check == $c)
		{
			echo "Palindrome";
		}
		else
		{
			echo "Not Palindrome";
		}
	}	
	if(isset($_POST['num']))
	{
		echo checkArmstrong($_POST['num']);
	}
?>

<!-- ///////////////////////////////////////////////////// -->
<html>
	<body>
		<h1>Task 06 (Number to Letter Conversion) </h1>
		<form method="post">  
			Enter any Number <input type="number" name="num"/><br><br> 
			<input type="submit" name="btn" value="Convert"/>
		</form>     
	</body>
</html>
<?php
	function convert($num)
	{
		$letters = ['zero','one','two','three','four','five','six','seven','eight','nine'];
		$num_array = str_split($num);
		foreach ($num_array as $a) 
		{	
			echo $letters[$a]. " ";
		}

	}
	if(isset($_POST['num']))
	{
		convert($_POST['num']);
	}
?>





