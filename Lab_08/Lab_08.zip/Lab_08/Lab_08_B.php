
<!DOCTYPE html>
<html>
<head>
   
</head>
    <body>
    	<h1>Phone Directory Task</h1>
        <form method="POST" >
            <input type="text" placeholder="Enter Name" name="name" required><br><br>
            <input type="number" placeholder="Enter Number"  name="phone" required><br><br>
            <input type="submit" value="ADD TO PHONEBOOK" name="add">
        </form>
    </body>
</html>

<?php

echo "<br><br><br>";


if(array_key_exists('add',$_POST))
{ 
  $name = $_POST['name'];
  $phone = $_POST['phone'];

  echo "<table border='\1'\>
    <tr>
        <td>NAME</td>
        <td>PHONE</td>
    </tr>
    <tr>
        <td>$name</td>
        <td>$phone</td>
    </tr>
    </table>";
}   
?>

<!-- /////////////////////////////////////// -->

<!DOCTYPE html>
<html>

  <body>
  	<h1>Email Validation</h1>
    <form method="POST" >
        <input type="text" placeholder="Enter Email" name="email" required>
        <input type="submit" value="CHECK" name="check">
    </form>
  </body>
</html>

<?php

echo "<br><br><br>";


if(array_key_exists('check',$_POST))
{ 
  $email = $_POST['email'];
  $email2 = explode('@', $email);
  if (sizeof($email2) > 2)
  {
    echo "Wrong Email - Contain more than one @.";
  }
  elseif(sizeof($email2) <= 1 )
  {
    echo "Wrong Email - Contain no @ sign.";
  }
  else
  {
    if( is_numeric(substr($email2[0], 0, 1)))
    {
      echo "Wrong email - first character is number.";
    }
    else
    {  
      if(preg_match('/\s/', $email))
      {
        echo "Wrong email - contains space";
      }
      else
      {
        $email3 = explode(".", $email);
        if(sizeof($email3) > 3)
        {
          echo "Wrong email - contains incorrect domain - use .com, .edu.pk, or co.uk instead.";
        }
        elseif(sizeof($email3) <= 1)
          echo "Wrong email - contains no domain.";
        elseif(sizeof($email3) == 2)
        {
          if($email3[1] == "com")
          {
            echo "<h2>Email is correct!</h2>";
          }
          else
          {
            echo "Wrong email - contains incorrect domain - use .com, .edu.pk, or co.uk instead.";
          }
        }
        elseif(sizeof($email3) == 3)
        {
          if($email3[1] == "edu" && $email3[2] == "pk")
          {
            echo "<h2>Email is Valid</h2>";
          }
          elseif($email3 == "co" && $email3 == "uk")
          {
            echo "<h2>Email is correct!</h2>";
          }
          else
          {
            echo "Wrong email - contains incorrect domain - use .com, .edu.pk, or co.uk instead.";
          }
        }
      }
    }
  }
}   

?>









