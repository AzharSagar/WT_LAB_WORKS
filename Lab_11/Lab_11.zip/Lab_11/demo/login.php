<?php session_start();

if(isset($_POST['submit'])){
  $arrayPage = array();

  $_SESSION["Page"]=$arrayPage;

   header("Location: index.php");
    exit;


  
}






?>



<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
	<link rel="stylesheet" href="bootstrap.css">
	<style>
		body{
               background: #fbfbfb;
           }
            .container{
           		width:500px;
           		margin-top:20px;
           		border:1px solid #dddddd;
           		background:#fff; 
           }
           .well{
               margin-left: auto;
           }
         .spacing{
               margin-top: 20px;
             margin-bottom: 20px;
           }
	</style>
</head>
<body>
	<br><br>
	       <div class="container">
          <div class="well well-sm">
              <h3>Sign In</h3>
          </div>
           <div class="row">
              
               <div class="col-md-12">
                   <form  method="post">
                       
                       <div class="form-group spacing">
                            <label for=""><b>User Name:</b></label>
                            <input type="text" name="uname" placeholder="Enter your username" class="form-control">
                       </div>
                       <div class="form-group spacing">
                            <label for=""><b>Password:</b></label>
                            <input type="text" name="upass" placeholder="Enter your password" class="form-control">
                       </div>
                       <div class="checkbox spacing">
                           <label for="">
                               <input type="checkbox" name="rememberme">  
                               <b>Remember Me</b></label>
                       </div>
                       <div class="spacing">
                           <input type="submit" name="submit" class="btn btn-primary btn-block"  >
       
                       </div>
                       <hr>
                        <p>Don't have an account?   <a href="#">Sign Up here</a></p>
                   </form>
               </div>
           </div>
       </div>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</body>
</html>