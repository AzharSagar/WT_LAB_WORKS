<?php


if($_POST["uname"] == "Munwar" && $_POST["upass"] == "16SW40"){
if(!empty($_POST["rememberme"])) {
	setcookie ("uname",$_POST["uname"],time()+ (86400 * 7));
	setcookie ("upass",$_POST["upass"],time()+ (86400 * 7));
	echo "Cookies set Successfully<br>";
	echo "Welcome User:".$_COOKIE["uname"]." and Rollno ".$_COOKIE["upass"];

}else {
	setcookie("uname","");
	setcookie("upass","");
	echo "Cookies  is Not Set";
}
 }
 else{
 	echo "Please Enter correct credential";
 }
?>
 
<p><a href="login.html"> Go to Login Page </a> </p>