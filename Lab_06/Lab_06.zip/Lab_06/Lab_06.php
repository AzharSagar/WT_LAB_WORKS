<?php
    echo "<h2>Task 01</h2>";
        echo "phpinfo() method will give us the related information";
		
    echo "<h2>Task 02</h2>";
    echo "Current Script owner:".get_current_user();
    echo '<br> document root directory     under which the current script is running'.getenv('document_root');
    echo '<br>operating system PHP is running :'.php_uname('s');
    
	echo "<h2>Task 03</h2>";
    $a=10;
    $b=20;
    echo 'before Swapping :<br>value of a is:'.$a.'<br>value of b is:'.$b;
    $a=$a+$b;
    $b=$a-$b;
    $a=$a-$b;
    echo '<br><br>After Swapping :<br>value of a is:'.$a.'<br>value of b is:'.$b;
    
	echo "<h2>Task 04</h2>";
    echo 'Tomorrow I’ll learn something new.<br>This is a bad command: del c:\*.*\$.';
    
	
    $value=2;
    $result=($value>30) ? "Greater than 30" : (($value>20) ? "Greater than 20" : 
    (($value>10) ? "Greater than 10" :"Less than 10"));
    echo $result;
	
   echo "<h2>Task 05</h2>";
	
        $url ='https://www.w3schools.com/php/php_variables.asp';
        $scheme = substr($url,0,4);
        $host= substr($url,8,17);
        $post = substr($url,26,30);
        echo '<br>Scheme:'.$scheme.'<br>Host: '.$host.'<br>Post: '.$post;
    $title ='PHP Programming';
        $A=1000;
        $B=2000;
        $C=3000;
        $D=3000;
?>
<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title?></title>
    <style>
        .common{
            color:blue;
        }
        td{
            padding: 5px;
        }
    </style>
</head>

<body>
    <!--<h3><?php echo $title?></h3>
    <a href="https://www.w3schools.com/php/php_variables.asp"><?php echo $title?></a>-->
    
    <h2>Task 06</h2>
    <table border="2px">
        <tbody>
            <tr>
                <td class="common">Salary of Mr. Munwar is:</td>
                <td><?php echo $A?>$</td>
            </tr>
            <tr>
                <td class="common">Salary of Mr. Sagar is:</td>
                <td><?php echo $B?>$</td>
            </tr>
            <tr>
                <td class="common">Salary of Mr. Azhar is:</td>
                <td><?php echo $C?>$</td>
            </tr>
            <tr>
                <td class="common">Salary of Mr. Akhlaque is:</td>
                <td><?php echo $D?>$</td>
            </tr>
        </tbody>
    </table>
</body>
</html>
