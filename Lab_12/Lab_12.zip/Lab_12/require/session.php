<?php


session_start();

if(!$_SESSION['customer'])
{
	
	
	header("location:login.php?messege=plz login your account first");
	
	

}


?>