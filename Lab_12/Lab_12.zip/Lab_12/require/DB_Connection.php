<?php

	class Singleton
	{
		public static $connection;
		private function __construct()
		{
			
		}
		public static function getConnection()
		{
			static $conn = null;
			static $host = "localhost:3306";
			static $user = "root";
			static $pass = "";
			static $database = "mydatabase";
			if(!isset($connection))
			{
				$connection = mysqli_connect($host, $user, $pass, $database);
			}
			return $connection;
		}
	}
	$obj = Singleton::getConnection();
	
	
?>