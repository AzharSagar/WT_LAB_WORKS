<?php

	
require_once("require/DB_Connection.php");
require_once("require/header.php" );

require_once("require/side_bar.php" );

$file = fopen("C:/xampp/htdocs/myfile.txt", "r");
	while(!feof($file))
	{
		$data = fgets($file);
		$part = explode(",",  $data);
		list($name, $dept, $roll) = $part;
		$sql="INSERT INTO `student`(`name`,`dept`,`roll`) VALUES('$name','$dept','$roll')";
		mysqli_query($obj, $sql);
		
	}
	
	if(isset($_GET['id']))
    {
    	$query = "delete from student where id = ".$_GET['id'];
    	$delete = mysqli_query($obj, $query);
    	if($delete)
    	{
    		echo "deleted";
    	}

    }

?>

<html>
<body>
<head>
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css"  href="css/datatables.min.css">         
	<script type="text/javascript" src="js/datatables.min.js"></script>
		<script type="text/javascript" language="javascript" class="init">
			$(document).ready(function() {
				$('#table_1').DataTable();
			} );
		</script>
</head>
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="table-agile-info">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3>View All Students</h3>
				</div>
				<div class="row w3-res-tb">
					<div class="col-sm-5 m-b-xs">
					</div>
					<div class="col-sm-4">
					</div>
					
				</div>
				<div class="table-responsive">
				<table id='table_1' class="table table-striped b-t b-light">
					<thead>
							<tr>
								<th>Student Id</th>
								<th>Name</th>
								<th>Department</th>
								<th>Roll#</th>
								<th>Update</th>
								<th>Delete</th>
							</tr>
					</thead>
						
						<tbody>

							<?php

								$query = "SELECT * FROM student";

								$result = mysqli_query( $obj, $query );

								if ( $result ) 
								{
									while ( $rows = mysqli_fetch_assoc( $result ) ) 
									{	

							?>
							<tr>

								<td>
									<?php echo $rows['id'];?>
								</td>
								<td>
									<?php echo $rows['name'];?>
								</td>
								<td>
									<?php echo $rows['dept'];?>
								</td>
								
								<td>
									<?php echo $rows['roll'];?>
								</td>
								
								<td>
								        <div class="label label-primary">
	<a style="color: white" href="edit_student.php?id=<?php echo $rows['id'];?>">Update</a>
																	
	
										</div>
								</td>

								<td>
								        <div class="label label-primary">
	<a style="color: white" href="view_students.php?id=<?php echo $rows['id'];?>">Delete</a>
																	
	
										</div>
								</td>


								</tr>
<?php
}


}
else
				{
					echo "No Record Found....";
				}


?>

  </tbody>
  </table>
</div>

</body>

</html>