<?php


require_once("require/DB_Connection.php");
require_once("require/header.php");
require_once("require/side_bar.php");

?>


<!DOCTYPE html>
<html>
<head>
		<title>Add Student</title>
</head>

<body>
 
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Add Student
                           
                        </header>
                        <div class="panel-body">
                 <form role="form" class="form-horizontal" enctype="multipart/form-data" method="POST">
                                
                                    
                                <div class="form-group has-success">
                                    <label class="col-lg-3 control-label">Student Name</label>
                                    <div class="col-lg-6">
                                        <input type="text" name="name" placeholder="" id="f-name" class="form-control">
                                        
                                    </div>
                                </div>
                                
                                <div class="form-group has-success">
                                    <label class="col-lg-3 control-label">Student Department</label>
                                    <div class="col-lg-6">
                                        <input type="text" name="dname" placeholder="" id="f-name" class="form-control">
                                        
                                    </div>
                                </div>

                                
                                <div class="form-group has-success">
                                    <label class="col-lg-3 control-label">Student Roll#</label>
                                    <div class="col-lg-6">
                                        <input type="text" name="roll" placeholder="" id="f-name" class="form-control">
                                        
                                    </div>
                                </div>
                                
                               
                                
                               
                                
                                
                              
                                   
                                
                              
                                </div>
                                
                              
                                
             
                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-6">
                                       <br/>
                                        <button class="btn btn-primary" name="Sub" type="submit">Add Student</button>
                                         
                                    </div>
                                </div>
                                  
                                 
                                   
                                    </div> 
                                </div>

                               </form>
                        </div>
                    </section>
                </div>
            </div>
                
           </body>
          </html>




<?php
	
		if(isset($_POST['Sub']))
		{
			
					
			
			$name = $_POST['name'];
			$dname = $_POST['dname'];
			$roll = $_POST['roll'];
			

            echo $name;
            echo $dname;
            echo $roll;
			
			
			$query = "INSERT into `student`(`name`, `dept`, `roll`)VALUES('$name','$dname','$roll')";  
		        $result = mysqli_query($obj, $query);
			if($result)
			{
				
				echo "Add Student successfully";
				
			}
			
			else
			{
				
				echo "Student Not Add";
				
			}
			
			
			
		}
	
?>
    
