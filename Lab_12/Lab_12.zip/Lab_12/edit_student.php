<?php


require_once("require/DB_Connection.php" );
require_once("require/header.php");
require_once("require/side_bar.php");

?>

<?php
     
        if(isset($_GET['id']))
        {
            $id=$_GET['id'];

           
            $name = "";
            $dept = "";
            $roll = "";
            $query= "SELECT * from student where id=".$id;

            $result=mysqli_query($obj, $query);

            while($rows=mysqli_fetch_assoc($result))
            {    

                $id=$rows['id'];        
                $name = $rows['name'];
                $dept = $rows['dept'];
                $roll = $rows['roll'];
            
            }


           

        }

    
?>
    


<!DOCTYPE html>
<html>
<head>
		<title>Update Student</title>
</head>

<body>
 
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Update Student
                        </header>
                        <div class="panel-body">
                 <form role="form" class="form-horizontal" enctype="multipart/form-data" method="GET" action="#">
                                
                                   
                                    
                               
                                
                                
                                <div class="form-group has-success">
                                    <label class="col-lg-3 control-label">Name</label>
                                    <div class="col-lg-6">
                                        <input type="text" name="update_name" placeholder="" id="f-name" class="form-control" value="<?php echo $name;?>">
                                        
                                    </div>
                                </div>
                                
                                <div class="form-group has-success">
                                    <label class="col-lg-3 control-label">Department</label>
                                    <div class="col-lg-6">
                                        <input type="text" name="update_dept" placeholder="" id="dept" class="form-control" value="<?php echo $dept; ?>">
                                        
                                    </div>
                                </div>

                                
                                <div class="form-group has-success">
                                    <label class="col-lg-3 control-label">Roll</label>
                                    <div class="col-lg-6">
                                        <input type="text" name="update_roll" placeholder="" id="roll" class="form-control" value="<?php echo $roll;?>">
                                        
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-6">
                                       <br/>
                                        <button class="btn btn-primary" name="update_student" type="submit">update_Student</button>
                                         
                                    </div>
                                </div>
                                      
                                    </div> 
                                </div>
                    <input type="hidden" name='id' value=<?php echo $id; ?> />
                               </form>
                        </div>
                    </section>
                </div>
            </div>
                
           </body>
          </html>
          <?php
          $id = $_GET['id'];
    if(isset($_GET['update_student']))
    {
      
      $name=$_GET['update_name'];
      $dept=$_GET['update_dept'];
      $roll=$_GET['update_roll'];
      $update_query="UPDATE `student` SET `name`='$name',`dept` = '$dept',`roll` = '$roll' WHERE `id` = ".$id;
       $run_update=mysqli_query($obj, $update_query);
    if($run_update)
    {
      echo "Updated Successfully";
    }
    else
    {
      echo "Not updated successfully";        
    }

    }


?>
