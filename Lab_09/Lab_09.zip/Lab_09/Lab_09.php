<?php
	


?>
<html>
	<head>
		<script src = "jquery-1.10.2.js"></script>
		<style>
			body {font-family: Arial, Helvetica, sans-serif;}
			* {box-sizing: border-box;}

			input[type=text], select, textarea {
			  width: 100%;
			  padding: 12px;
			  border: 1px solid #ccc;
			  border-radius: 4px;
			  box-sizing: border-box;
			  margin-top: 6px;
			  margin-bottom: 16px;
			  resize: vertical;
			}

			input[type=submit] {
			  background-color: #4CAF50;
			  color: white;
			  padding: 12px 20px;
			  border: none;
			  border-radius: 4px;
			  cursor: pointer;
			}

			input[type=submit]:hover {
			  background-color: #45a049;
			}

			.container {
			  border-radius: 5px;
			  background-color: #f2f2f2;
			  padding: 20px;
			}
			</style>
		<script type="text/javascript">
			$(document).ready(function(){
				$(".head").click(function(){
					$(".head").hide();
				});

				$("#p").dblclick(function(){
					$("#p").css("background-color" , "red");
				});
				$("#first").focus(function(){
					var value1 = $("#first").val();
					$("#span").text(value1);
				});
				$("#middle").focus(function(){
					var value2 = $("#middle").val();
					$("#span").text(value2);
				});
				$("#last").focus(function(){
					var value3 = $("#last").val();
					$("#span").text(value3);
				});
				$("#name").click(function(){
					$("#name").prop("disabled", true);
				});
				$("#show").click(function(){
					alert("clicked");
					var length = $("#list li").length;
					alert("Total length : "+length);
				});
				$("#btn").click(function(){
					fname = $("#fname").val();
					lname = $("#lname").val();
					email = $("#email").val();
					subject= $("#subject").val();
					$.ajax({
						url : "Lab_09.php",
						method : "post",
						data : {
							fname : fname,
							lname : lname,
							email : email,
							subject : subject
						},
						success : function(data){
							alert("data successfully sent");
							$("#fname").val("");
							$("#lname").val("");
							$("#email").val("");
							$("#subject").val("");
						}
						
					});
				});
				$("#country").click(function(){
					
					var pakistan = ["Nawabshah", "Badin", "Sukkur"];
					var dubai = ["Sharjah","Abu Dahabi","Dubai"];
					var japan = ["Tokyo", "Osaka", "Kyoto"];
					var a =  $("#country").val();
					if(a=="Pakistan")
					{
						$("#city").html("");
						$.ajax({
							success : function(data)
							{
								
								var itmes = "";
								for(var a = 0; a<3; a++)
								{
									console.log(pakistan[a]);
									itmes += "<option>" + pakistan[a] + "</option>";
								}	
								$("#city").append(itmes);
							}
							
						});
					}
					else if(a=="Dubai")
					{
						$("#city").html("");
						$.ajax({
							success : function(data)
							{
								var itmes = "";
								for(var a = 0; a<3; a++)
								{
									
									itmes += "<option>" + dubai[a] + "</option>";
								}	
								$("#city").append(itmes);
							}
							
						});
					}
					else if(a=="Japan")
					{
						$("#city").html("");
						$.ajax({
							success : function(data)
							{
								var itmes = "";
								for(var a = 0; a<3; a++)
								{
									console.log(japan[a]);
									itmes += "<option>" + japan[a] + "</option>";
								}	
								$("#city").append(itmes);
							}
							
						});
					}
				});


			});

		</script>
	</head>
	<body>
		<h1>Task 1 (JQUERY)</h1>
		<h1 class = "head">Heading 1</h1>
		<h2 class = "head">Heading 2</h2>
		<h3 class = "head">Heading 3</h3>
		<h4 class = "head">Heading 4</h4>
		<h5 class = "head">Heading 5</h5>
		<h6 class = "head">Heading 6</h6>
		
		<!-- /////////////////////////////////  -->
		<h1>Task 2 (JQUERY)</h1>
		<p id = "p" style = "font-size: 20px;">Bhatti Azhar Hussain 16sw64</p>

		<!-- /////////////////////////////////  -->
		<h1>Task 3 (JQUERY)</h1>
		<div style="width: 40%; height: 40%;">
			First Name : <input type="text" name = "fname" id = "first" /> <br><br>
			Middle Name : <input type="text" name="mname" id = "middle" /> <br><br>
			Last Name : <input type="text" name= "lname" id = "last" /> <br><br>
			<span id = "span">
				
			</span>
		</div>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<!-- /////////////////////////////////  -->
		<h1>Task 4 (JQUERY)</h1>
		<div style="width: 40%; height: 40%;">
			Name : <input type="text" name = "name" id = "name" /> <br><br>
			Roll#: <input type="text" name="roll" id = "roll" /> <br><br>
		</div>

		<!-- /////////////////////////////////  -->
		<h1>Task 5 (JQUERY)</h1>
		<ul id = "list">
			<li>1</li>
			<li>2</li>
			<li>3</li>
			<li>4</li>
			<li>5</li>
			<li>6</li>
		</ul>
		<input type="submit" value = "show" id = "show" />

		<!-- /////////////////////////////////  -->
			<h1>Task 6 (AJAX) </h1>

			<h3>Contact Form</h3>
			<div style="width: 40%; height: 40%;">
			<div class="container">
			  <form action="" method = "post">
			    <label for="fname">First Name</label>
			    <input type="text" id="fname" name="firstname" placeholder="Your name..">

			    <label for="lname">Last Name</label>
			    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

			    <label for="email">Email</label>
			    <input type="text" id="email" name="email" placeholder="Your Email..">

			    <label for="subject">Subject</label>
			    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>

			  <input type="submit" value="Submit" id = "btn" >
			  </form>
			</div>
			</div>
			<br><br><br><br><br><br><br><br><br><br><br><br><br>
			<br><br><br><br><br><br><br><br><br><br><br><br><br>

			<!-- /////////////////////////////////  -->
			<h1>Task 7 (AJAX) </h1>
			<div style="width: 40%; height: 40%;">			
			 	<label for="country">Country</label>
		    	<select id="country" name="country">
		      		<option value="Pakistan">Pakistan</option>
		      		<option value="Japan">Japan</option>
		      		<option value="Dubai">Dubai</option>
		    	</select>
		    	<label for="city">City</label>
		    	<select id="city" name="city">
		
		    	</select>
		    </div>
	</body>
</html>