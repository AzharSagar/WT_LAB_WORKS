<!DOCTYPE HTML>
<html>
<head>
	<title>Lab 13</title>
</head>
<body> 


<form method="POST">
  <label>Student Name: </label>
  <input type="text" name="stdName"><br>
  <label>Roll No:</label>
  <input type="text" name="rollno">
  <input type="submit" value="SUBMIT" >
</form>

<?php

std_name = $_POST["stdName"];
roll_no= $_POST["rollno"];

$std_array= array();

$conn= mysqli_connect("localhost","root","","demo_base")
or
die("Error connecting to database ".mysql_error());

$rst = mysqli_query($conn,"SELECT * FROM student WHERE roll_no='roll_no' ") 
or die("Query not executed".mysqli_error());

while ($k=mysqli_fetch_assoc($rst)){
	array_push($std_array, $k);
}

echo json_encode($std_array);

mysqli_close($conn);

?>

</body>

</html>