<?php

	echo "<h1>Task 1 </h1>";
	$file_handler = fopen("my_file.txt", "r+");
	$data = fread($file_handler, 1024);
	echo "<h3>The File Data</h3>";
	echo $data. "<br>";
	echo "<h3>Total Words Using str_word_count() :  ".str_word_count($data). "</h3>";
	$data_array = explode(" ", $data);
	$count = 0;
	$linecount = 0;
	for($i=0; $i<count($data_array); $i++)
	{
		$count++;
		$line = fgets($file_handler);
  		$linecount++;
	}
	

	echo "<h3>Total Words Using Explode() : ".$count. "</h3>";
	echo "<h3>Comparison</h3>";
	echo "The str_word_count() don't count numbers as String but explode does <br>";
	$file = "my_file.txt";  
	$lines = COUNT(FILE($file));  
	ECHO "<h4>There are $lines lines in $file</h4>";
?>
<!-- ////////////////////////////////////////////////////////////////////// -->
<?php
	echo "<h1>Task 2 </h1>";
	
    

?>
<!-- ////////////////////////////////////////////////////////////////////// -->
<?php
	echo "<h1>Task 3 </h1>";
	$file_handler = fopen("temp.txt", "a");
	$data = fwrite($file_handler, "16SW64");
	$file_handler = fopen("temp.txt", "r+");
	$data = fread($file_handler, 1024);
	echo $data;


?>