<form enctype="multipart/form-data" action="" method="POST">
    <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
    Choose File Here : <input name="userfile" type="file" />
    <input type="submit" value="Upload" />
    <br><br>
    <input type = "submit" name ="delete" value = "Delete"/>
     <br><br>
    <input type = "submit" name ="move" value = "Move"/>
</form>
<?php

$uploaddir = 'C:/xampp/htdocs/Labs/Lab_10/';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);

echo '<pre>';
if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) 
{
    echo "File is valid, and was successfully uploaded.\n";
} 
else 
{
    echo "Possible file upload attack!\n";
}

echo 'Here is some more debugging info:<br>';
print_r($_FILES);

print "</pre>";
echo "uploadfile = ".$_FILES['userfile']['name']."<br>";
	echo "<h3> The uploaded File Data : <br> </h3>";
	$data = file_get_contents($uploadfile); 
	echo $data;

?>