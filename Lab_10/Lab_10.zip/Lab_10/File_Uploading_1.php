<?php
   if(isset($_FILES['file']))
   {
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size = $_FILES['image']['size'];
      $file_tmp = $_FILES['image']['tmp_name'];
      $file_type = $_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $extensions= array("pdf","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false)
      {
         $errors[]="please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2000000) 
      {
         $errors[]='File size must be >= 2 MB';
      }
      
      if(empty($errors)==true) 
      {
         move_uploaded_file($file_tmp,"images/".$file_name);
         echo "File Uploaded Successfully <br>";
         echo "<h3>Image Name : ".$_FILES['image']['name'] . "<br>"; 
         echo "<h3>File Size : ".$_FILES['image']['size']. "<br>";  
         echo "<h3>File Type : ".$_FILES['image']['type']. "<br>";
         
      }
   }
?>
<html>
   <body>
      
      <form action = "" method = "POST" enctype = "multipart/form-data">
         <input type = "file" name = "file" />
         <input type = "submit" value = "uplaod"/>
      </form>
   </body>
</html>
<!-- ///////////////////////////////////// -->
<!-- The data encoding type, enctype, MUST be specified as below -->
<form enctype="multipart/form-data" action="" method="POST">
    <!-- MAX_FILE_SIZE must precede the file input field -->
    <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
    <!-- Name of input element determines name in $_FILES array -->
    Send this file: <input name="userfile" type="file" />
    <input type="submit" value="Send File" />
</form>
<?php
// In PHP versions earlier than 4.1.0, $HTTP_POST_FILES should be used instead
// of $_FILES.

$uploaddir = 'C:/xampp/htdocs/Labs/Lab_10/';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);

echo '<pre>';
if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
    echo "File is valid, and was successfully uploaded.\n";
} else {
    echo "Possible file upload attack!\n";
}

echo 'Here is some more debugging info:';
print_r($_FILES);

print "</pre>";

?>