<?php
	
	echo "<h2>Task 01</h2>";
	for($i=1; $i<=50; $i++)
	{
		if($i%3==0 && $i%5==0)
		{
			echo "StarTruck" . "\n\n\n";
		}
		elseif($i%3==0)
		{
			echo "Star" . "\n\n\n";
		}
		elseif($i%5==0)
		{
			echo "Truck" . "\n\n\n";
		}
		else
		{
			echo $i . "<br/>";
		}
	}
	echo "<h2>Task 02</h2>";
	$num1 = 62;
	$num2 = 02;
	$sum = $num1 + $num2;
	
	if($sum==64):
		echo "Its Your Lucky day";
		
	elseif ($sum!=64):
		echo "Its not Your Lucky day";
		
	else:
		echo "Neither Lucky nor UnLucky day";
		
	endif;
	echo "<h2>Task 03</h2>";
	$name = "AZHAR";
	
	
	$str = "";
	$lenght = strlen($name);
	for($i=0; $i<$lenght; $i++)
	{   
		$a = $name[$i];
		
		if($a=="A")
		{
			$word = "Apple";
			$str = $str . $word . " ";
		}
		elseif($a=="Z")
		{
			$word = "Zebra";
			$str = $str . $word . " ";
		}
		elseif($a=="H")
		{
			$word = "Hen";
			$str = $str . $word . " ";
		}
		elseif($a=="R")
		{
			$word = "Rose";
			$str = $str . $word . " ";
		}
	}
	echo "Name :  ".$name . "</br>" ;
	echo $str;
	
	echo "<h2>Task 04</h2>";
	for($i=0; $i<=10; $i++)
	{
		if($i%2==0)
		{
			goto even;
		}else{
			goto odd;
		}
		even:
			echo "even:"."\n". $i . "</br>";
			continue;
		odd:
			echo "odd"."\n". $i . "</br>";
	}
	
	echo "<h2>Task 05</h2>";
	
	echo "<table border = 4, rowspan = 10, width = '50%'>";
	for($i=1; $i<=7; $i++)
	{	
		echo "<tr>";
		for($j=1; $j<=7; $j++)
		{
			echo "<td>".($i*$j)."</td>";
		}
		echo "</tr>";
		
	}
	echo "</table>";
	
	echo "<h2>Task 06</h2>";
	
	$arr = array( "Italy"=>"Rome", "Luxembourg"=>"Luxembourg", "Belgium"=> "Brussels", "Denmark"=>"Copenhagen", "Finland"=>"Helsinki", "France" => "Paris", "Slovakia"=>"Bratislava", "Slovenia"=>"Ljubljana", "Germany" => "Berlin", "Greece" => "Athens", "Ireland"=>"Dublin", "Netherlands"=>"Amsterdam", "Portugal"=>"Lisbon", "Spain"=>"Madrid", "Sweden"=>"Stockholm", "United Kingdom"=>"London", "Cyprus"=>"Nicosia", "Lithuania"=>"Vilnius", "Czech Republic"=>"Prague", "Estonia"=>"Tallin", "Hungary"=>"Budapest", "Latvia"=>"Riga", "Malta"=>"Valetta", "Austria" => "Vienna", "Poland"=>"Warsaw") ;
	echo "The Capital of Italy is ".$arr['Italy'] . "<br/>";
	echo "The Capital of Netherlands is ".$arr['Netherlands'] . "<br/>";
	echo "The Capital of Germany is ".$arr['Germany'] . "<br/>";

	echo "<h2>Task 07</h2>";
	
	$arr = [1,2,3,4,5];
	$arr[2] = "@";
	$arr[3] = "$";
	array_shift($arr);
	foreach($arr as $a)
	{
		echo $a . "<br/>";
	}
	
	echo "<h2>Task 08</h2>";
	$numbers = range(200, 250, 4);
	foreach ($numbers as $a) { 
      		echo "$a " . "<br/>"; 
	} 
  
	
	echo "<h2>Task 09</h2>";
	$array1 = array(1, 20, "A", 0, 25, "A");
	$array2 = array(1, 10, 100, "C", "B");
	$output = array_merge(array_diff($array1, $array2), array_diff($array2, $array1));
	foreach($output as $a)
	{
		echo $a . "<br/>";
	}
	//print_r($output);
	
	echo "<h2>Task 10</h2>";
	$color = array ( "color" => array ( "a" => "Red", "b" => "Green", "c" => "White"),"numbers" => array ( 1, 2, 3, 4, 5, 6 ),"holes" => array ( "First", 5 => "Second", "Third"));
	echo $color["color"]["c"]. "</br>";
	echo $color["numbers"]["1"]. "</br>";
	echo $color["holes"]["5"] . "</br>";
	
	echo "<h2>Task 11</h2>";
	$associative_array = array("Samreen"=>"31","Jahan"=>"41","Warisha"=>"39","Rania"=>"40");
	
	echo "Associative Array In Ascending Order By value" . "<br/>";
	asort($associative_array);
	foreach($associative_array as $x => $x_value)
	{
		echo "Key=" . $x . ", Value=" . $x_value;
		echo "<br>";
	}
	echo "<br>";
	echo "Associative Array In Ascending Order By Key" . "<br/>";
	ksort($associative_array);
	foreach($associative_array as $x => $x_value)
	{
		echo "Key=" . $x . ", Value=" . $x_value;
		echo "<br>";
	}
	echo "<br>";
	
	echo "Associative Array In Descending Order By Value" . "<br/>";
	arsort($associative_array);
	foreach($associative_array as $x => $x_value)
	{
		echo "Key=" . $x . ", Value=" . $x_value;
		echo "<br>";
	}
	echo "<br>";
	
	echo "Associative Array In Descending Order By Key" . "<br/>";
	krsort($associative_array);
	foreach($associative_array as $x => $x_value)
	{
		echo "Key=" . $x . ", Value=" . $x_value;
		echo "<br>";
	}
	echo "<br>";
	
	echo "<h2>Task 12</h2>";
	
	for($i = 1; $i<=10; $i++)
	{
		$var = rand(1,200);
		$arr[$i] = $var; 
	}
	
	foreach($arr as $a)
	{
		if($a==64)
		{
			echo "Roll# Number found :  ".$a;
			break;
		}else
		{
			echo "Not Found ".$a."</br>";
		}
	}
	echo "<h2>Task 13</h2>";
	
	$d = 'A00';
	for($i=1; $i<=5; $i++)
	{
		echo ++$d . "</br>";
		//echo $d."</br>";
	}


?>